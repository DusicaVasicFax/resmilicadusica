﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for AddController.xaml
    /// </summary>
    public partial class AddController : Window
    {
        public AddController()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                long period = long.Parse(TextBoxPeriod.Text);
                LocalController.LocalControllers lc = new LocalControllers(TextBoxCode.Text, period);
                MainWindow.LocalControllerList.Add(lc);
                MainWindow.localControllersIds.Add(lc.LCCode);
                this.Close();
            }

        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private bool Validate()
        {
            bool result = true;

            if (TextBoxPeriod.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelPeriodGreska.Content = "Obavezan unos!";
                TextBoxPeriod.BorderBrush = Brushes.Red;
                TextBoxPeriod.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    long period = long.Parse(TextBoxPeriod.Text.Trim());

                    if (period < 0)
                    {
                        result = false;
                        LabelPeriodGreska.Content = "Mora biti pozitivan broj!";
                        TextBoxPeriod.BorderBrush = Brushes.Red;
                        TextBoxPeriod.BorderThickness = new Thickness(2);
                    }
                }
                catch (Exception)
                {
                    result = false;
                    LabelPeriodGreska.Content = "Nekorektan unos!";
                    TextBoxPeriod.BorderBrush = Brushes.Red;
                    TextBoxPeriod.BorderThickness = new Thickness(2);
                }
            }

            if (TextBoxCode.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelCodeGreska.Content = "Obavezan unos!";
                TextBoxCode.BorderBrush = Brushes.Red;
                TextBoxCode.BorderThickness = new Thickness(2);
            }
            else
            {
                int code = int.Parse(TextBoxCode.Text.Trim());
                if (code < 0)
                {
                    result = false;
                    LabelCodeGreska.Content = "Mora biti pozitivan broj!";
                    TextBoxCode.BorderBrush = Brushes.Red;
                    TextBoxCode.BorderThickness = new Thickness(2);

                }
            }
            return result;

        }
    }
}
