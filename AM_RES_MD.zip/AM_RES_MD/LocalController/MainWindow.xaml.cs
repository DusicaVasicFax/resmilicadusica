﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static ObservableCollection<LocalDevices> LocalDeviceList { get; set; }
        public static ObservableCollection<LocalController.LocalControllers> LocalControllerList { get; set; }
        public static ObservableCollection<string> localControllersIds { get; set; }
        

        public MainWindow()
        {
            InitializeComponent();
            LocalDeviceList = new ObservableCollection<LocalDevices>();
            LocalControllerList = new ObservableCollection<LocalControllers>();
            localControllersIds = new ObservableCollection<string>();
            DataContext = this;
           
        }

        private void AddNewController_Click(object sender, RoutedEventArgs e)
        {
            AddController ac = new AddController();
            ac.ShowDialog();

        }

        private void AddNewDevice_Click(object sender, RoutedEventArgs e)
        {
            AddDevice ad = new AddDevice();
            ad.ShowDialog();
        }

        private void DeleteDevice_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.LocalDeviceList.RemoveAt(dataGridDevice.SelectedIndex);
        }

        private void TurnON_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalDeviceList.Count; i++)
            {
                if (i == dataGridDevice.SelectedIndex)
                {
                    LocalDeviceList[i].TurnOn();
                }
            }
        }

        private void TurnOFF_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalDeviceList.Count; i++)
            {
                if (i == dataGridDevice.SelectedIndex)
                {
                    LocalDeviceList[i].TurnOff();

                }
            }
        }

        private void DeleteController_Click(object sender, RoutedEventArgs e)
        {
            LocalController.LocalControllers lc = MainWindow.LocalControllerList.ElementAt(dataGridController.SelectedIndex);
            List<LocalDevices> pom = MainWindow.LocalDeviceList.ToList();
            foreach (LocalDevices ld in pom)
            {
                if (ld.LocalDeviceControllerCode.Equals(lc.LCCode))
                {
                    MainWindow.LocalDeviceList.Remove(ld);
                }
            }
            MainWindow.localControllersIds.RemoveAt(dataGridController.SelectedIndex);
            MainWindow.LocalControllerList.RemoveAt(dataGridController.SelectedIndex);


        }

        private void TurnONController_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalControllerList.Count; i++)
            {
                if (i == dataGridController.SelectedIndex)
                {
                    LocalControllerList[i].TurnOn();
                }
            }

        }

        private void TurnOFFController_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalControllerList.Count; i++)
            {
                if (i == dataGridController.SelectedIndex)
                {
                    LocalControllerList[i].TurnOff();

                }
            }
        }
    }
}
