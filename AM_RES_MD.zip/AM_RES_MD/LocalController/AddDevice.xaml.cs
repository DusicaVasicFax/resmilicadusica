﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for AddDevice.xaml
    /// </summary>
    public partial class AddDevice : Window
    {
        public static List<string> typeList = new List<string>() { "Digital", "Analog" };
        public static List<string> destinationList = new List<string>() { "Local controller", "AMS" };

        public AddDevice()
        {
            InitializeComponent();
            comboBoxType.ItemsSource = typeList;
            comboBoxDestination.ItemsSource = destinationList;
            comboBoxController.ItemsSource = MainWindow.localControllersIds;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
               
                    foreach (LocalDevices ld in LocalController.MainWindow.LocalDeviceList)
                    {
                        if (textBoxCode.Text.Equals(ld.LDCode))
                        {
                            textBoxCode.Text = textBoxCode.GetHashCode().ToString(); //ukoliko ime vec postoji, ime ovog LD-a postaje hash code
                            break;
                        }
                    }

                    LocalDevices dev = new LocalDevices(textBoxCode.Text, long.Parse(textBoxPeriod.Text), Int32.Parse(textBoxLimit.Text), comboBoxType.SelectedItem.ToString(), comboBoxDestination.SelectedItem.ToString(), comboBoxController.SelectedItem.ToString());
                    MainWindow.LocalDeviceList.Add(dev);

                    foreach (LocalController.LocalControllers lc in MainWindow.LocalControllerList)
                    {
                        if (lc.LCCode.Equals(comboBoxController.SelectedItem.ToString()))
                        {
                            lc.Devices.Add(dev);
                        }
                    }

                    this.Close();
                
            }

        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private bool Validate()
        {
            bool result = true;

            if (textBoxPeriod.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelPeriodGreska.Content = "Obavezan unos!";
                textBoxPeriod.BorderBrush = Brushes.Red;
                textBoxPeriod.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    long period = long.Parse(textBoxPeriod.Text.Trim());

                    if (period < 0)
                    {
                        result = false;
                        LabelPeriodGreska.Content = "Mora biti pozitivan broj!";
                        textBoxPeriod.BorderBrush = Brushes.Red;
                        textBoxPeriod.BorderThickness = new Thickness(2);
                    }
                }
                catch (Exception)
                {
                    result = false;
                    LabelPeriodGreska.Content = "Nekorektan unos!";
                    textBoxPeriod.BorderBrush = Brushes.Red;
                    textBoxPeriod.BorderThickness = new Thickness(2);
                }
            }

            if (textBoxLimit.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelLimitGreska.Content = "Obavezan unos!";
                textBoxLimit.BorderBrush = Brushes.Red;
                textBoxLimit.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    int limit = Int32.Parse(textBoxPeriod.Text.Trim());

                    if (limit < 0)
                    {
                        result = false;
                        LabelLimitGreska.Content = "Mora biti pozitivan broj!";
                        textBoxLimit.BorderBrush = Brushes.Red;
                        textBoxLimit.BorderThickness = new Thickness(2);
                    }
                }
                catch (Exception)
                {
                    LabelLimitGreska.Content = "Nekorektan unos!";
                    textBoxLimit.BorderBrush = Brushes.Red;
                    textBoxLimit.BorderThickness = new Thickness(2);
                }
            }

            if (comboBoxType.SelectedItem == null)
            {
                result = false;
                LabelTypeGreska.Content = "Obavezan odabir!";
                comboBoxType.BorderBrush = Brushes.Red;
                comboBoxType.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelTypeGreska.Content = String.Empty;
                comboBoxType.BorderBrush = Brushes.Transparent;
            }

            if (comboBoxDestination.SelectedItem == null)
            {
                result = false;
                LabelDestGreska.Content = "Obavezan odabir!";
                comboBoxDestination.BorderBrush = Brushes.Red;
                comboBoxDestination.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelDestGreska.Content = String.Empty;
                comboBoxDestination.BorderBrush = Brushes.Transparent;
            }

            return result;
        }
    }
}
