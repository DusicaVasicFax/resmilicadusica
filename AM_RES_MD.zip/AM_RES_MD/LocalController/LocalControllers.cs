﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LocalController
{
    public class LocalControllers : INotifyPropertyChanged
    {
        private string lCCode;
        private long lCTimestamp;
        private List<LocalDevices> devices;
        private bool lCState;
        private static int LCcount = 0;

        public event PropertyChangedEventHandler PropertyChanged;

        #region Property
        public string LCCode
        {
            get { return lCCode; }
            set
            {
                if (lCCode != value)
                {
                    lCCode = value;
                    RaisePropertyChanged("LCCode");
                }
            }
        }
        public long LCTimestamp {
            get { return lCTimestamp; }
            set
            {
                if (lCTimestamp != value)
                {
                    lCTimestamp = value;
                    RaisePropertyChanged("LCTimestamp");
                }
            }
        }
        
        public bool LCState {
            get { return lCState; }
            set
            {
                if (lCState != value)
                {
                    lCState = value;
                    RaisePropertyChanged("LCState");
                }
            }
        }

        public List<LocalDevices> Devices { get => devices; set => devices = value; }


        #endregion
        #region Konstruktori
        public LocalControllers()
        {
            lCCode = "";
            lCTimestamp = -1;
            Devices = new List<LocalDevices>();
            lCState = false;
        }

        public LocalControllers(string code, long period)
        {
            LCcount++;
            lCCode = code;
            lCTimestamp = period;
            lCState = true;
            Devices = new List<LocalDevices>();

        }
        #endregion

        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        public void TurnOn()
        {
            if (this.LCState)
            {
                MessageBox.Show("Nemoguće uključiti kontroler, jer je već uključen!", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                this.LCState = true;
            }
        }

        public void TurnOff()
        {
            if (this.LCState)
            {
                this.LCState = false;
            }
            else
            {
                MessageBox.Show("Nemoguće isključiti kontroler, jer je već isključen!", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
