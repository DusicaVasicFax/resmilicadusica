﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LocalController
{
    public class LocalDevices : INotifyPropertyChanged
    {
        private string lDCode;
        private int lDTimestamp;
        //Int32 unixTimestamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        private int lDValue;
        private int lDLimit;
        private string lDType;
        private bool lDState;
        private string lDDestination;
        private List<int> lDValues;
        private string localDeviceControllerCode;
        
        private static int LDCount = 0;
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        #region Property

        public string LDCode
        {
            get { return lDCode; }
            set
            {
                if (lDCode != value)
                {
                    lDCode = value;
                    RaisePropertyChanged("LDCode");
                }
            }
        }

        public bool LDState
        {
            get { return lDState; }
            set
            {
                if (lDState != value)
                {
                    lDState = value;
                    RaisePropertyChanged("LDState");
                }
            }
        }

        public int LDValue
        {
            get { return lDValue; }
            set
            {
                if (lDValue != value)
                {
                    lDValue = value;
                    RaisePropertyChanged("LDValue");
                }
            }
        }

        public int LDTimestamp
        {
            get { return lDTimestamp; }
            set
            {
                if (lDTimestamp != value)
                {
                    lDTimestamp = value;
                    RaisePropertyChanged("LDTimestamp");
                }
            }
        }

        public int LDLimit
        {
            get { return lDLimit; }
            set
            {
                if (lDLimit != value)
                {
                    lDLimit = value;
                    RaisePropertyChanged("LDLimit");
                }
            }
        }

        public string LDType
        {
            get { return lDType; }
            set
            {
                if (lDType != value)
                {
                    lDType = value;
                    RaisePropertyChanged("LDType");
                }
            }
        }

        public string LDDestination
        {
            get { return lDDestination; }
            set
            {
                if (lDDestination != value)
                {
                    lDDestination = value;
                    RaisePropertyChanged("LDDestination");
                }
            }
        }

        public List<int> LDValues
        {
            get
            {
                return lDValues;

            }

            set
            {
                if (lDValues != value)
                {
                    lDValues = value;
                    RaisePropertyChanged("LDValues");
                }
            }
        }

        public string LocalDeviceControllerCode
        {
            get
            {
                return localDeviceControllerCode;
            }

            set
            {
                if (localDeviceControllerCode != value)
                {
                    localDeviceControllerCode = value;
                    RaisePropertyChanged("LocalDeviceCodeControllerCode");
                }
            }
        }
        #endregion
        #region Konstruktori

        public LocalDevices()
        {
            lDCode = "";
            lDTimestamp = -1;
            lDValue = -1;
            lDLimit = -1;
            lDState = false;
            lDType = "";
            lDDestination = "";
            lDValues = new List<int>();
            localDeviceControllerCode = "";
        }

        public LocalDevices(string code, int period, int limit, string type, string destination, string lcCode)
        {
            LDCount++;
            lDCode = code;
            lDTimestamp = period;
            lDValue = 0;
            lDLimit = limit;
            lDState = false;
            lDType = type;
            lDDestination = destination;
            lDValues = new List<int>();
            localDeviceControllerCode = lcCode;
        }

        #endregion

        public void TurnOn()
        {
            if (this.LDState)
            {
                MessageBox.Show("Nemoguće uključiti uređaj, jer je već uključen!", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                this.LDState = true;
            }
        }

        public void TurnOff()
        {
            if (this.LDState)
            {
                this.LDState = false;
            }
            else
            {
                MessageBox.Show("Nemoguće isključiti uređaj, jer je već isključen!", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
