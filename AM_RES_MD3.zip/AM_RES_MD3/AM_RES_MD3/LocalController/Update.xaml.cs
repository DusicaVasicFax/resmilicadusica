﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        private LocalDevices device;
        public static List<string> typeList = new List<string>() { "Digital", "Analog" };
        public static List<string> destinationList = new List<string>() { "Local controller", "AMS" };

        public Update(LocalDevices dev)
        {
            InitializeComponent();


            device = dev;
            textBoxCode.Text = device.LDCode.GetHashCode().ToString();
            textBoxPeriod.Text = device.LDTimestamp.ToString();
            textBoxLimit.Text = device.LDLimit.ToString();
           
            comboBoxType.SelectedValue = device.LDType.ToString();
            comboBoxDestination.SelectedValue = device.LDDestination.ToString();
            comboBoxController.SelectedValue = device.LocalDeviceControllerCode.ToString();
            comboBoxType.ItemsSource = typeList;
            comboBoxDestination.ItemsSource = destinationList;
            comboBoxController.ItemsSource = MainWindow.localControllersIds;
        }

        private bool Validate()
        {
            bool result = true;

            if (textBoxCode.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelCodeGreska.Content = "Obavezan unos!";
                textBoxCode.BorderBrush = Brushes.Red;
                textBoxCode.BorderThickness = new Thickness(2);

            }
            else
            {
                try
                {
                    int kod = int.Parse(textBoxCode.Text.Trim());

                    if (kod < 0)
                    {
                        result = false;
                        LabelCodeGreska.Content = "Mora biti pozitivan broj!";
                        textBoxCode.BorderBrush = Brushes.Red;
                        textBoxCode.BorderThickness = new Thickness(2);
                    }
                    
                }
                catch (Exception)
                {
                    result = false;
                    LabelCodeGreska.Content = "Nekorektan unos!";
                    textBoxCode.BorderBrush = Brushes.Red;
                    textBoxCode.BorderThickness = new Thickness(2);
                }

            }


            if (textBoxPeriod.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelPeriodGreska.Content = "Obavezan unos!";
                textBoxPeriod.BorderBrush = Brushes.Red;
                textBoxPeriod.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    long period = long.Parse(textBoxPeriod.Text.Trim());

                    if (period < 0)
                    {
                        result = false;
                        LabelPeriodGreska.Content = "Mora biti pozitivan broj!";
                        textBoxPeriod.BorderBrush = Brushes.Red;
                        textBoxPeriod.BorderThickness = new Thickness(2);
                    }
                }
                catch (Exception)
                {
                    result = false;
                    LabelPeriodGreska.Content = "Nekorektan unos!";
                    textBoxPeriod.BorderBrush = Brushes.Red;
                    textBoxPeriod.BorderThickness = new Thickness(2);
                }
            }

            if (textBoxLimit.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelLimitGreska.Content = "Obavezan unos!";
                textBoxLimit.BorderBrush = Brushes.Red;
                textBoxLimit.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    int limit = int.Parse(textBoxLimit.Text.Trim());

                    if (limit < 0)
                    {
                        result = false;
                        LabelLimitGreska.Content = "Mora biti pozitivan broj!";
                        textBoxLimit.BorderBrush = Brushes.Red;
                        textBoxLimit.BorderThickness = new Thickness(2);
                    }
                }
                catch (Exception)
                {
                    LabelLimitGreska.Content = "Nekorektan unos!";
                    textBoxLimit.BorderBrush = Brushes.Red;
                    textBoxLimit.BorderThickness = new Thickness(2);
                }
            }

            if (comboBoxType.SelectedItem == null)
            {
                result = false;
                LabelTypeGreska.Content = "Obavezan odabir!";
                comboBoxType.BorderBrush = Brushes.Red;
                comboBoxType.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelTypeGreska.Content = String.Empty;
                comboBoxType.BorderBrush = Brushes.Transparent;
            }

            if (comboBoxDestination.SelectedItem == null)
            {
                result = false;
                LabelDestGreska.Content = "Obavezan odabir!";
                comboBoxDestination.BorderBrush = Brushes.Red;
                comboBoxDestination.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelDestGreska.Content = String.Empty;
                comboBoxDestination.BorderBrush = Brushes.Transparent;
            }

            return result;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                device.LDCode = textBoxCode.Text.ToString();
                device.LDTimestamp = int.Parse(textBoxPeriod.Text.ToString());
                device.LDLimit = Int32.Parse(textBoxLimit.Text.ToString());
                device.LDType = comboBoxType.SelectedValue.ToString();
                device.LDDestination = comboBoxDestination.SelectedValue.ToString();
                device.LocalDeviceControllerCode = comboBoxController.SelectedValue.ToString();

                Window1.LocalDeviceList.ResetBindings();
                this.Close();
                
            }

        }
    }
}
