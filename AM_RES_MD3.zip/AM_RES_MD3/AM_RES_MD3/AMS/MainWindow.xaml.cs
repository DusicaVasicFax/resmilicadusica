﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<string> controllers { get; set; }
        public static List<LocalController.LocalDevices> devices { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            controllers = new List<string>();
            devices = new List<LocalController.LocalDevices>();

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
            foreach(var s in LocalController.MainWindow.localControllersIds)
            {
                controllers.Add(s);
            }

            /*foreach(var d in LocalController.Window1.LocalDeviceList)
            {
                devices.Add(d);
            }

            foreach(var s in controllers)
            {
                textBox1.Text = s.LCCode.ToString();
                textBox1.Text = "\n ";
            }

            foreach(var d in devices)
            {
                textBox.Text = d.LDCode.ToString();
                textBox.Text = "\n ";
            }*/

        }
    }
}
