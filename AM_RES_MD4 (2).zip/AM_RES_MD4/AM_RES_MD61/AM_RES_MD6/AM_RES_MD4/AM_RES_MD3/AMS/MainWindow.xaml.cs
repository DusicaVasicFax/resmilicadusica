﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace AMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<string> listaVrednosti { get; set; }
        public static List<string> ListaRadniSati { get; set; }
        public static Dictionary<string, List<string>> pairs { get; set; }

        private static List<int> ListValue { get; set; }
        private static List<DateTime> ListTime { get; set; }
        public static int limit;


        public MainWindow()
        {
            InitializeComponent();
            //devices = new ObservableCollection<string>();

            listaVrednosti = new List<string>();
            ListaRadniSati = new List<string>();
            pairs = new Dictionary<string, List<string>>();

            ListValue = new List<int>();
            ListTime = new List<DateTime>();

            DataContext = this;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string path1 = $"../../../LocalController/bin/Debug/Devices1/device.txt";
            string path = $"../../../LocalController/bin/Debug/Controllers1/controller.txt";

            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            FileStream fs1 = new FileStream(path1, FileMode.Open, FileAccess.Read);

            byte[] buffer = new byte[1024];
            string str = "";


            if (fs.CanRead)
            {
                fs.Read(buffer, 0, buffer.Length);
            }

            str = Encoding.Default.GetString(buffer);
            string s = "";
            string[] split = str.Split('\n');

            foreach (var l in split)
            {
                s += l + '\n';
            }

            textBox1.Text = s;

            fs.Flush();
            fs.Close();


            byte[] buffer1 = new byte[1024];
            string str1 = "";


            if (fs1.CanRead)
            {
                fs1.Read(buffer1, 0, buffer1.Length);
            }

            str1 = Encoding.Default.GetString(buffer1);
            string s1 = "";
            string[] split1 = str1.Split('\n');

            foreach (var l in split1)
            {
                s1 += l + '\n';
            }

            textBox.Text = s1;

            fs1.Flush();
            fs1.Close();

        }
        private void Show_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateShow_Click())
            {
                // 06/05/20 15:40:00
                DateTime dateTimeStart = DateTime.ParseExact(textBoxStart.Text, "dd/MM/yy HH:mm:ss", null);
                DateTime dateTimeEnd = DateTime.ParseExact(textBoxEnd.Text, "dd/MM/yy HH:mm:ss", null);

                string path = "../../../AMS/bin/Debug/Controllers/ams.xml";
                string path1 = "../../../AMS/bin/Debug/Devices/toAMS.xml";

                if (File.Exists(path))
                {
                    lock (path)
                    {
                        XDocument doc = XDocument.Load(path);
                        IEnumerable<XElement> elements = (from el in doc.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD.Text.ToString() select el); //ovde su svi device


                        IEnumerable<XElement> values = (from el in elements.Descendants("value") select el); //ovde su sve vrednosti

                        foreach (XElement xe in values)
                        {
                            if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) <= dateTimeEnd)
                                listaVrednosti.Add("Value: " + xe.Value + " time: " + xe.FirstAttribute.Value); //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                        }
                        doc.Save(path);
                    }
                }

                if (File.Exists(path1))
                {
                    lock (path1)
                    {
                        XDocument doc1 = XDocument.Load(path1);
                        IEnumerable<XElement> elements1 = (from el in doc1.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD.Text.ToString() select el); //ovde su svi device


                        IEnumerable<XElement> values1 = (from el in elements1.Descendants("value") select el); //ovde su sve vrednosti

                        foreach (XElement xe in values1)
                        {
                            if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) <= dateTimeEnd)
                                listaVrednosti.Add("Value: " + xe.Value + " time: " + xe.FirstAttribute.Value); //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                        }
                        doc1.Save(path1);
                    }
                }

                textBoxReport.Text = String.Join(Environment.NewLine, listaVrednosti);
                listaVrednosti.Clear();
            }

        }
        private void buttonShow_Click(object sender, RoutedEventArgs e)
        {
            if (ValidatebuttonShow_Click())
            {
                // 06/05/20 15:40:00
                DateTime dateTimeStart = DateTime.ParseExact(textBoxStartRadniSati.Text, "dd/MM/yy HH:mm:ss", null);
                DateTime dateTimeEnd = DateTime.ParseExact(textBoxEndRadniSati.Text, "dd/MM/yy HH:mm:ss", null);

                string path = "../../../AMS/bin/Debug/Controllers/ams.xml";
                string path1 = "../../../AMS/bin/Debug/Devices/toAMS.xml";

                int exact;


                if (File.Exists(path))
                {
                    lock (path)//mi
                    {
                        XDocument doc = XDocument.Load(path);

                    
                        IEnumerable<XElement> elements = (from el in doc.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD.Text.ToString() select el); //ovde su svi device

                        IEnumerable<XElement> values = (from el in elements.Descendants("value") select el); //ovde su sve vrednosti

                        foreach (XElement xe in values)
                        {

                            if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) <= dateTimeEnd)
                                ListaRadniSati.Add("Time :" + xe.FirstAttribute.Value); //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                        }

                        doc.Save(path);

                        if (ListaRadniSati.Count == 0)
                        {
                            textBoxReportRadniSati.Text = "Local device " + textBoxLDRadniSati.Text + " je imao " + '0' + " radna sata u izabranom periodu.";
                        }
                        else
                        {
                            string[] s = ListaRadniSati[0].Split(' ');
                            string[] aa = s[1].Split(':');
                            string p = aa[1] + ' ' + s[2];
                            string[] a = ListaRadniSati[ListaRadniSati.Count - 1].Split(' ');
                            string[] kk = a[1].Split(':');
                            string k = kk[1] + ' ' + a[2];

                            DateTime pocetak = DateTime.ParseExact(p, "dd/MM/yy HH:mm:ss", null);
                            DateTime kraj = DateTime.ParseExact(k, "dd/MM/yy HH:mm:ss", null);

                            if (dateTimeStart.Date == dateTimeEnd.Date)
                            {
                                exact = (Math.Abs(kraj.Hour - pocetak.Hour) + Math.Abs(kraj.Minute - pocetak.Minute) + Math.Abs(kraj.Second - pocetak.Second));
                                textBoxReportRadniSati.Text = "Local device " + textBoxLDRadniSati.Text + " je imao " + Decimal.Divide(exact, 100).ToString() + " radna sata u izabranom periodu.";
                            }
                            else
                            {

                                string[] l = k.Split('/');
                                string ll = l[0];
                                exact = (Math.Abs(24 - pocetak.Hour) + Math.Abs(60 - pocetak.Minute) + Math.Abs(60 - pocetak.Second)
                                    + Math.Abs(Int32.Parse(ll)) + kraj.Hour + kraj.Minute + kraj.Second);

                            }

                            if (pairs.ContainsKey(textBoxLDRadniSati.Text))
                            {
                                pairs[textBoxLDRadniSati.Text].Add(ListaRadniSati.ToString());//ne valja ovo
                            }
                            else
                            {
                                pairs.Add(textBoxLDRadniSati.Text, ListaRadniSati);
                            }
                        }
                    }
                }

                if (File.Exists(path1))
                {
                    lock (path1)//mi
                    {
                        XDocument doc1 = XDocument.Load(path1);
                    
                        IEnumerable<XElement> elements1 = (from el in doc1.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD.Text.ToString() select el); //ovde su svi device


                        IEnumerable<XElement> values1 = (from el in elements1.Descendants("value") select el); //ovde su sve vrednosti

                        foreach (XElement xe in values1)
                        {
                            if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", null) <= dateTimeEnd)
                                ListaRadniSati.Add("Time :" + xe.FirstAttribute.Value);  //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                        }
                        doc1.Save(path1);

                        if (ListaRadniSati.Count == 0)
                        {
                            textBoxReportRadniSati.Text = "Local device " + textBoxLDRadniSati.Text + " je imao " + '0' + " radna sata u izabranom periodu.";

                        }
                        else
                        {
                            string[] s = ListaRadniSati[0].Split(' ');
                            string[] aa = s[1].Split(':');
                            string p = aa[1] + ' ' + s[2];
                            string[] a = ListaRadniSati[ListaRadniSati.Count - 1].Split(' ');
                            string[] kk = a[1].Split(':');
                            string k = kk[1] + ' ' + a[2];

                            DateTime pocetak = DateTime.ParseExact(p, "dd/MM/yy HH:mm:ss", null);
                            DateTime kraj = DateTime.ParseExact(k, "dd/MM/yy HH:mm:ss", null);

                            if (pocetak.Date == kraj.Date)
                            {
                                exact = (Math.Abs(kraj.Hour - pocetak.Hour) + Math.Abs(kraj.Minute - pocetak.Minute) + Math.Abs(kraj.Second - pocetak.Second));
                                textBoxReportRadniSati.Text = "Local device " + textBoxLDRadniSati.Text + " je imao " + Decimal.Divide(exact, 100).ToString() + " radna sata u izabranom periodu.";
                            }
                            else
                            {

                                string[] l = k.Split('/');
                                string ll = l[0];
                                exact = (Math.Abs(24 - pocetak.Hour) + Math.Abs(60 - pocetak.Minute) + Math.Abs(60 - pocetak.Second)
                                    + Math.Abs(Int32.Parse(ll)) + kraj.Hour + kraj.Minute + kraj.Second);
                            }

                            if (pairs.ContainsKey(textBoxLDRadniSati.Text))
                            {
                                pairs[textBoxLDRadniSati.Text].Add(ListaRadniSati.ToString());//ne valja ovo
                            }
                            else
                            {
                                pairs.Add(textBoxLDRadniSati.Text, ListaRadniSati);
                            }
                        }
                    }
                }

                ListaRadniSati.Clear();
            }
        }
        private void Show4_Click(object sender, RoutedEventArgs e)
        {
            if (checkboxAMS.IsChecked == true && checkboxLC.IsChecked == true)
            {
                MessageBox.Show("Ne možete izabrati i AMS i Lokalni kontroler.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (checkboxAMS.IsChecked == false && checkboxLC.IsChecked == false)
            {
                MessageBox.Show("Morate odabrati jedno (ili AMS ili Lokalni kontroler).", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (BrPromena.IsChecked == true && BrRadnihSati.IsChecked == true)
            {
                MessageBox.Show("Ne možete označiti i broj radnih sati, i broj promena.", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (BrPromena.IsChecked == false && BrRadnihSati.IsChecked == false)
            {
                MessageBox.Show("Morate označiti jedno polje (ili broj radnih sati, ili broj promena.)", "", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (checkboxLC.IsChecked == true && textBoxNameLC.Text.Trim().Equals(String.Empty))
            {
                labelLC.Content = "Obavezan unos!";
                textBoxNameLC.BorderBrush = Brushes.Red;
                textBoxNameLC.BorderThickness = new Thickness(2);

            }

            if (textBoxLimit.Text.Trim().Equals(String.Empty))
            {
                labelLimit.Content = "Obavezan unos!";
                textBoxLimit.BorderBrush = Brushes.Red;
                textBoxLimit.BorderThickness = new Thickness(2);
            }
            else
            {
                limit = Int32.Parse(textBoxLimit.Text);
            }
            
            string imeLC = textBoxNameLC.Text;
            string text = String.Empty;
           
                if (checkboxAMS.IsChecked == true)
                {
                string path = "../../../AMS/bin/Debug/Devices/toAMS.xml";

                lock (path)
                {
                    XDocument doc = XDocument.Load(path);

                    IEnumerable<XElement> elements = (from el in doc.Descendants("device") select el);

                    Dictionary<string, List<string>> vrednosti = new Dictionary<string, List<string>>();

                    foreach (XElement xe in elements)
                    {
                        IEnumerable<XElement> values = (from el in xe.Descendants("value") select el);

                        foreach (XElement val in values)
                        {
                            if (vrednosti.ContainsKey(xe.Attribute("code").Value))
                            {
                                vrednosti[xe.Attribute("code").Value].Add(xe.Value);
                            }
                            else
                            {
                                vrednosti.Add(xe.Attribute("code").Value, new List<string>() { xe.Value });
                            }
                        }
                    }

                    if (BrRadnihSati.IsChecked == true)
                    {
                        foreach (var k in pairs)
                        {
                            for (int i = 0; i < pairs.Count; i++)
                            {
                                if(Int32.Parse(k.Value[i])>limit)
                                {
                                    text += "Local device: " + k.Key + " Broj radnih sati: " + k.Value + "\n";

                                }
                            }
                        }

                        textBox4.Text = text;
                    }
                    else if (BrPromena.IsChecked == true)
                    {
                        foreach (KeyValuePair<string, List<string>> kv in vrednosti)
                        {
                            
                                if (kv.Value.Count > limit)
                                {
                                    text += "Local device: " + kv.Key + " Broj promena: " + kv.Value.Count + "\n";     
                                }
                            
                        }

                        textBox4.Text = text;
                        textBox4.BorderBrush = Brushes.Red;
                    }
                }
            } else if (checkboxLC.IsChecked == true)
            {
                string path = "../../../AMS/bin/Debug/Controllers/ams.xml";

                lock (path)
                {
                    XDocument doc = XDocument.Load(path);

                    IEnumerable<XElement> elements = (from el in doc.Descendants("controller") where (string)el.Attribute("code").Value == imeLC select el);

                    Dictionary<string, List<string>> vrednosti = new Dictionary<string, List<string>>();

                    foreach (XElement xe in elements)
                    {
                        IEnumerable<XElement> devices = xe.Descendants("device");

                        foreach (XElement xed in devices)
                        {
                            IEnumerable<XElement> values = xed.Descendants("value");

                            foreach (XElement v in values)
                            {
                                if (vrednosti.ContainsKey(xed.Attribute("code").Value))
                                {
                                    vrednosti[xed.Attribute("code").Value].Add(xed.Value);
                                }
                                else
                                {
                                    vrednosti.Add(xed.Attribute("code").Value, new List<string>() { xed.Value });
                                }
                            }
                        }
                    }

                    if (BrRadnihSati.IsChecked == true)
                    {
                        
                        foreach (var k in pairs)
                        {
                            if (vrednosti.ContainsKey(k.Key))
                            {
                                for (int i = 0; i < pairs.Count; i++)
                                {
                                    if (Int32.Parse(k.Value[i]) > limit)
                                    {
                                        text += "Local device: " + k.Key + " Broj radnih sati: " + k.Value + "\n";

                                    }
                                }
                            }
                        }

                    textBox4.Text = text;
                    }
                    else if (BrPromena.IsChecked == true)
                    {
                        foreach (KeyValuePair<string, List<string>> kv in vrednosti)
                        {
                            
                                if (kv.Value.Count > limit)
                                {
                                    text += "Local device: " + kv.Key + " Broj promena: " + kv.Value.Count + "\n";
                                }
                            
                        }
                        textBox4.Text = text;
                    }
                }
            }
        }
        private void Draw_Click(object sender, RoutedEventArgs e)
        {

            DateTime dateTimeStart = DateTime.ParseExact(textBoxStart2.Text, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None);
            DateTime dateTimeEnd = DateTime.ParseExact(textBoxEnd2.Text, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None);

            string path = "../../../AMS/bin/Debug/Controllers/ams.xml";
            if (File.Exists(path))
            {
                lock (path)
                {
                    XDocument doc = XDocument.Load(path);
                
                    IEnumerable<XElement> elements = (from el in doc.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD2.Text.ToString() select el); //ovde su svi device
                    IEnumerable<XElement> values = (from el in elements.Descendants("value") select el); //ovde su sve vrednosti

                    foreach (XElement xe in values)
                    {
                        if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None) <= dateTimeEnd)
                        {
                            ListValue.Add(Int32.Parse(xe.Value)); //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                            ListTime.Add(DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None));
                        }
                    }
                    doc.Save(path);
                }
            }

            string path1 = "../../../AMS/bin/Debug/Devices/toAMS.xml";

            if (File.Exists(path1))
            {
                lock (path1)
                {
                    XDocument doc1 = XDocument.Load(path1);
                
                    IEnumerable<XElement> elements1 = (from el in doc1.Descendants("device") where (string)el.Attribute("code").Value == textBoxLD2.Text.ToString() select el); //ovde su svi device
                    IEnumerable<XElement> values1 = (from el in elements1.Descendants("value") select el); //ovde su sve vrednosti

                    foreach (XElement xe in values1)
                    {
                        if (DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None) >= dateTimeStart && DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None) <= dateTimeEnd)
                        {
                            ListValue.Add(Int32.Parse(xe.Value)); //ovde ubacujemo one vrednosti koje upadaju u vreme izmedju
                            ListTime.Add(DateTime.ParseExact(xe.FirstAttribute.Value, "dd/MM/yy HH:mm:ss", new CultureInfo("en-US"), DateTimeStyles.None));
                        }
                    }
                    doc1.Save(path1);
                }
            }
            int countTemp = ListValue.Count;
            int countTime = ListTime.Count;

            List<KeyValuePair<DateTime, int>> data1 = new List<KeyValuePair<DateTime, int>>();

            if (countTemp == countTime)
            {
                for (int i = 0; i < countTemp; i++)
                {
                    KeyValuePair<DateTime, int> dt = new KeyValuePair<DateTime, int>(ListTime[i], ListValue[i]);
                    data1.Add(dt);
                }
            }

            if (data1[0].Value == 0 || data1[0].Value == 1)
            {
                MessageBox.Show("This graph works only for analog local devices!", "", MessageBoxButton.OK, MessageBoxImage.Error);
                ListValue.Clear();
                ListTime.Clear();
                
            }
            else
            {
                series.ItemsSource = data1;
                ListValue.Clear();
                ListTime.Clear();
            }



        }

        private void checkboxAMS_LayoutUpdated(object sender, EventArgs e)
        {
            if (checkboxAMS.IsChecked == true)
            {
                textBoxNameLC.Visibility = Visibility.Collapsed;
            }
            else
            {
                textBoxNameLC.Visibility = Visibility.Visible;
            }
        }
        private bool ValidatebuttonShow_Click()
        {
            bool result = true;

            if (textBoxStartRadniSati.Text.Trim().Equals(String.Empty))
            {
                result = false;
                label.Content = "Obavezan unos!";
                textBoxStartRadniSati.BorderBrush = Brushes.Red;
                textBoxStartRadniSati.BorderThickness = new Thickness(2);

            }
            /*else 
            {
                try
                {
                   DateTime a= DateTime.ParseExact(textBoxStartRadniSati.Text, "dd/MM/yy HH:mm:ss", null); 
                }
                catch
                {
                    result = false;
                    label.Content = "Pogresan format unosa!Pratite labelu iznad!";
                    textBoxStartRadniSati.BorderBrush = Brushes.Red;
                    textBoxStartRadniSati.BorderThickness = new Thickness(2);
                }

            }*/

            if (textBoxEndRadniSati.Text.Trim().Equals(String.Empty))
            {
                result = false;
                label1.Content = "Obavezan unos!";
                textBoxEndRadniSati.BorderBrush = Brushes.Red;
                textBoxEndRadniSati.BorderThickness = new Thickness(2);

            }
            /*else
            {
                try
                {
                    DateTime a = DateTime.ParseExact(textBoxEndRadniSati.Text, "dd/MM/yy HH:mm:ss", null);
                }
                catch
                {
                    result = false;
                    label1.Content = "Pogresan format unosa!Pratite labelu iznad!";
                    textBoxEndRadniSati.BorderBrush = Brushes.Red;
                    textBoxEndRadniSati.BorderThickness = new Thickness(2);
                }

            }*/

            if (textBoxLDRadniSati.Text.Trim().Equals(string.Empty))
            {
                result = false;
                label2.Content = "Obavezan unos!";
                textBoxLDRadniSati.BorderBrush = Brushes.Red;
                textBoxLDRadniSati.BorderThickness = new Thickness(2);

            }

            return result;
        }
        private bool ValidateShow_Click()
        {
            bool result = true;

            if (textBoxStart.Text.Trim().Equals(String.Empty))
            {
                result = false;
                label6.Content = "Obavezan unos!";
                textBoxStart.BorderBrush = Brushes.Red;
                textBoxStart.BorderThickness = new Thickness(2);

            }
            /*else 
            {
                try
                {
                   DateTime a= DateTime.ParseExact(textBoxStartRadniSati.Text, "dd/MM/yy HH:mm:ss", null); 
                }
                catch
                {
                    result = false;
                    label.Content = "Pogresan format unosa!Pratite labelu iznad!";
                    textBoxStartRadniSati.BorderBrush = Brushes.Red;
                    textBoxStartRadniSati.BorderThickness = new Thickness(2);
                }

            }*/

            if (textBoxEnd.Text.Trim().Equals(String.Empty))
            {
                result = false;
                label5.Content = "Obavezan unos!";
                textBoxEnd.BorderBrush = Brushes.Red;
                textBoxEnd.BorderThickness = new Thickness(2);

            }
            /*else
            {
                try
                {
                    DateTime a = DateTime.ParseExact(textBoxEndRadniSati.Text, "dd/MM/yy HH:mm:ss", null);
                }
                catch
                {
                    result = false;
                    label1.Content = "Pogresan format unosa!Pratite labelu iznad!";
                    textBoxEndRadniSati.BorderBrush = Brushes.Red;
                    textBoxEndRadniSati.BorderThickness = new Thickness(2);
                }

            }*/

            if (textBoxLD.Text.Trim().Equals(string.Empty))
            {
                result = false;
                label4.Content = "Obavezan unos!";
                textBoxLD.BorderBrush = Brushes.Red;
                textBoxLD.BorderThickness = new Thickness(2);

            }

            return result;

        }
        
    }

}
