﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    /// 

    public partial class Window1 : Window
    {
        public static BindingList<LocalDevices> LocalDeviceList { get; set; }
        Random rand = new Random();
        XmlWriter xmlWriter;
        
        int a = TimeCalc.ThreadTimeDevice()*1000;

        public Window1()
        {

            InitializeComponent();
            LocalDeviceList = new BindingList<LocalDevices>();
            DataContext = this;

            DevicesValue();
            
        }

        private void DevicesValue()
        {
            var thread1 = new Thread(() =>
            {
                while (true)
                {
                    lock (LocalDeviceList)
                    {
                        foreach (LocalDevices ld in LocalDeviceList)
                        {
                            if (ld.LDState)
                            {
                                foreach (LocalControllers lc in MainWindow.LocalControllerList)
                                {
                                    
                                        if (ld.LDType.Equals("Digital"))
                                        {
                                            
                                            ld.LDValue = rand.Next(0, 2);
                                            ld.LDValues.Add(ld.LDValue);

                                            if (ld.LDDestination.Equals("LK"))
                                            {
                                                SaveToLC(ld.LDCode, $@"../Debug/Devices/{ld.LocalDeviceControllerCode}.xml", ld.LDValue);
                                            }
                                            else
                                            {
                                                SaveToAMS(ld.LDCode, $"../../../AMS/bin/Debug/Devices/toAMS.xml", ld.LDValue, "/");
                                                
                                            }

                                        }
                                        else
                                        {
                                            ld.LDValue = rand.Next(210, 240);
                                            ld.LDValues.Add(ld.LDValue);
                                            if (ld.LDDestination.Equals("LK"))
                                            {
                                                SaveToLC(ld.LDCode, $@"../Debug/Devices/{ld.LocalDeviceControllerCode}.xml", ld.LDValue);
                                                
                                            }
                                            else
                                            {
                                                SaveToAMS(ld.LDCode, $"../../../AMS/bin/Debug/Devices/toAMS.xml", ld.LDValue, "/");
                                               
                                            }

                                        }     
                                }
                            }
                        }
                        Thread.Sleep(a);
                    }
                }
            });
            thread1.IsBackground = true;
            thread1.Start();
        }

        public void SaveToAMS(string code, string file, int value, string controllerCode)
        {
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            xmlWriterSettings.Indent = true;
            xmlWriterSettings.NewLineOnAttributes = true;

            if (!File.Exists(file))
            {
                xmlWriter = XmlWriter.Create(file, xmlWriterSettings);

                using (xmlWriter)
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("devices");
                    xmlWriter.WriteStartElement("device");
                    xmlWriter.WriteAttributeString("code", code);

                    xmlWriter.WriteStartElement("value");
                    xmlWriter.WriteAttributeString("time", DateTime.Now.ToString());
                    xmlWriter.WriteRaw(value.ToString());

                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteEndElement(); //zatvoren device
                    xmlWriter.WriteEndElement(); //zatvoren devices
                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();

                }
            }
            else
            {

                XElement doc1 = XElement.Load(file);
                XElement element = (from el in doc1.Elements() where (string)el.Attribute("code").Value == code select el).FirstOrDefault();

                if (element == null)
                {
                    XDocument doc = XDocument.Load(file);
                    XElement root = new XElement("device");
                    root.Add(new XAttribute("code", code));

                    XElement val = new XElement("value", value.ToString());
                    val.Add(new XAttribute("time", DateTime.Now.ToString()));
                    root.Add(val);


                    doc.Element("devices").Add(root);
                    doc.Save(file);

                }
                else
                {

                    XElement val = new XElement("value", value.ToString());
                    val.Add(new XAttribute("time", DateTime.Now.ToString()));
                    element.Add(val);
                    doc1.Save(file);
                }
            }
        }

        public void SaveToLC(string code, string file, int value)
        {
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            xmlWriterSettings.Indent = true;
            xmlWriterSettings.NewLineOnAttributes = true;

            if (!File.Exists(file))
            {
                xmlWriter = XmlWriter.Create(file, xmlWriterSettings);

                using (xmlWriter)
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("devices");
                    xmlWriter.WriteStartElement("device");
                    xmlWriter.WriteAttributeString("code", code);

                    xmlWriter.WriteStartElement("value");
                    xmlWriter.WriteAttributeString("time", DateTime.Now.ToString());
                    xmlWriter.WriteRaw(value.ToString());

                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteEndElement(); //zatvoren device
                    xmlWriter.WriteEndElement(); //zatvoren devices
                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();

                }
            }
            else
            {

                XElement doc1 = XElement.Load(file);
                XElement element = (from el in doc1.Elements() where (string)el.Attribute("code").Value == code select el).FirstOrDefault();

                if (element == null)
                {
                    XDocument doc = XDocument.Load(file);
                    XElement root = new XElement("device");
                    root.Add(new XAttribute("code", code));

                    XElement val = new XElement("value", value.ToString());
                    val.Add(new XAttribute("time", DateTime.Now.ToString()));
                    root.Add(val);


                    doc.Element("devices").Add(root);
                    doc.Save(file);

                }
                else
                {

                    XElement val = new XElement("value", value.ToString());
                    val.Add(new XAttribute("time", DateTime.Now.ToString()));
                    element.Add(val);
                    doc1.Save(file);
                }
            }
        }

        

        private void AddNewDevice_Click(object sender, RoutedEventArgs e)
        {
            AddDevice ad = new AddDevice();
            ad.ShowDialog();
        }

        private void DeleteDevice_Click(object sender, RoutedEventArgs e)
        {
            lock (Window1.LocalDeviceList)
            {
                string path = $"../../../LocalController/bin/Debug/Devices1/device.txt";
                FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                byte[] buffer = new byte[1024];
                string str= "";
                

                if (fs.CanRead)
                {
                    fs.Read(buffer, 0, buffer.Length);
                }
                
                str = Encoding.Default.GetString(buffer);
                string s = "";
                string[] split = str.Split('\n');
                for (int i = 0; i < split.Length; i++)
                {
                    if (split[i] != LocalDeviceList[dataGridDevice.SelectedIndex].LDCode)
                    {
                        s+=split[i]+'\n';
                    }
                }

                fs.Flush();
                fs.Close();
                
                FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
                byte[] buff = Encoding.Default.GetBytes(s);
                if (fileStream.CanWrite)
                {
                    fileStream.Write(buff, 0, buff.Length);
                }

                fileStream.Flush();
                fileStream.Close();
                
                Window1.LocalDeviceList.RemoveAt(dataGridDevice.SelectedIndex);
            }
        }

        private void TurnON_Click(object sender, RoutedEventArgs e)
        {
            lock (LocalDeviceList)
            {
                for (int i = 0; i < LocalDeviceList.Count; i++)
                {
                    if (i == dataGridDevice.SelectedIndex)
                    {
                        LocalDeviceList[i].TurnOn();
                    }
                }
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            Update ad = new Update((LocalDevices)dataGridDevice.SelectedItem);
            ad.ShowDialog();
        }

        private void TurnOFF_Click(object sender, RoutedEventArgs e)
        {
           lock (LocalDeviceList)
            {
                for (int i = 0; i < LocalDeviceList.Count; i++)
                {
                    if (i == dataGridDevice.SelectedIndex)
                    {
                        LocalDeviceList[i].TurnOff();

                    }
                }
            }
        }

        
    }
}
