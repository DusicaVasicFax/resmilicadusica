﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public static ObservableCollection<LocalController.LocalControllers> LocalControllerList { get; set; }
        public static ObservableCollection<string> localControllersIds { get; set; }
        Random rand = new Random();
        
        XmlWriter xmlWriter1;
        Window1 win = new Window1();
        static int a = TimeCalc.ThreadTime() * 1000;
        int b = a + 1000;

        public MainWindow()
        {
            InitializeComponent();
            
            LocalControllerList = new ObservableCollection<LocalControllers>();
            localControllersIds = new ObservableCollection<string>();
           
            win.Show();
            DataContext = this;
            
            SendToAMS();
            DeleteBuffer();

        }

        public void SendToAMS()
        {
            var thread1 = new Thread(() =>
            {
                while (true)
                {
                    string path = $@"./Devices";
                    string[] files = Directory.GetFiles(path);

                    XmlWriterSettings xmlWriterSettings1 = new XmlWriterSettings();
                    xmlWriterSettings1.Indent = true;
                    xmlWriterSettings1.NewLineOnAttributes = true;

                    if (!File.Exists($"../../../AMS/bin/Debug/Controllers/ams.xml"))
                    {

                        xmlWriter1 = XmlWriter.Create("../../../AMS/bin/Debug/Controllers/ams.xml", xmlWriterSettings1);

                        using (xmlWriter1)
                        {
                            xmlWriter1.WriteStartDocument();
                            xmlWriter1.WriteStartElement("controllers");
                            xmlWriter1.WriteEndElement();
                            xmlWriter1.WriteEndDocument();
                            xmlWriter1.Flush();
                            xmlWriter1.Close();
                        }
                    }
                    else
                    {
                        XDocument doc = XDocument.Load("../../../AMS/bin/Debug/Controllers/ams.xml");

                        
                            foreach (string f in files)
                            {
                                lock (f)
                                {
                                    var controllerFile = XDocument.Load(f);
                                    XElement item = XElement.Load(f);
                                    XElement element = (from el in item.Elements() where (string)el.Attribute("code") == System.IO.Path.GetFileNameWithoutExtension(f) select el).FirstOrDefault();

                                    if (element == null)
                                    {
                                        XElement controller = new XElement("controller");
                                        controller.Add(new XAttribute("code", System.IO.Path.GetFileNameWithoutExtension(f)));
                                        controller.Add(new XAttribute("time", DateTime.Now.ToString()));
                                        controller.Add(controllerFile.Root.Elements());
                                        doc.Element("controllers").Add(controller);
                                    }
                                    else
                                    {
                                        element.Add(controllerFile.Root.Elements());
                                    }
                                }
                            
                            }
                        doc.Save("../../../AMS/bin/Debug/Controllers/ams.xml");
                    }
                 Thread.Sleep(a);
                }
                
            });
            
            thread1.IsBackground = true;
            thread1.Start();
        }

        private void DeleteBuffer()
        {
            string path = $@"./Devices";
            string trazenoImeFilea = "";

            var thread1 = new Thread(() =>
            {
                while (true)
                {
                        foreach (LocalControllers lc in MainWindow.LocalControllerList)
                        {
                        lock (path)
                        {
                            if (Directory.EnumerateFileSystemEntries(path).Any())
                            {
                                if (lc.LCState)
                                {
                                    string[] files = Directory.GetFiles(path);
                                    foreach (string filename in files)
                                    {

                                        var temp = filename.Substring(10, lc.LCCode.Length);
                                        if (lc.LCCode.Equals(temp))
                                        {
                                            trazenoImeFilea = temp;
                                            break;
                                        }
                                    }

                                    File.Delete(path + "/" + trazenoImeFilea + ".xml");
                                }
                            }

                        }
                        }
                    Thread.Sleep(a);
                }
            });
            thread1.IsBackground = true;
            thread1.Start();
        }
        

        private void AddNewController_Click(object sender, RoutedEventArgs e)
        {
            AddController ac = new AddController();
            ac.ShowDialog();

        }

        private void DeleteController_Click(object sender, RoutedEventArgs e)
        {
            LocalController.LocalControllers lc = MainWindow.LocalControllerList.ElementAt(dataGridController.SelectedIndex);
            List<LocalDevices> pom = Window1.LocalDeviceList.ToList();

            lock (LocalControllerList)
            {
                lock (localControllersIds)
                {
                    lock (Window1.LocalDeviceList)
                    {
                        foreach (LocalDevices ld in pom)
                        {
                            if (ld.LocalDeviceControllerCode.Equals(lc.LCCode))
                            {
                                //   Window1.LocalDeviceList.Remove(ld);
                                MessageBox.Show("Ažurirajte kontroler kod uređaja sa kodom " + ld.LDCode + " , zbog prestanka rada kontrolera sa kodom " + lc.LCCode);
                            }

                        }

                        string path = $"../../../LocalController/bin/Debug/Controllers1/controller.txt";
                        FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                        byte[] buffer = new byte[1024];
                        string str = "";


                        if (fs.CanRead)
                        {
                            fs.Read(buffer, 0, buffer.Length);
                        }

                        str = Encoding.Default.GetString(buffer);
                        string s = "";
                        string[] split = str.Split('\n');
                        for (int i = 0; i < split.Length; i++)
                        {
                            if (split[i] != LocalControllerList[dataGridController.SelectedIndex].LCCode)
                            {
                                s += split[i] + '\n';
                            }
                        }

                        fs.Flush();
                        fs.Close();

                        FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
                        byte[] buff = Encoding.Default.GetBytes(s);
                        if (fileStream.CanWrite)
                        {
                            fileStream.Write(buff, 0, buff.Length);
                        }

                        fileStream.Flush();
                        fileStream.Close();

                        MainWindow.localControllersIds.RemoveAt(dataGridController.SelectedIndex);
                        MainWindow.LocalControllerList.RemoveAt(dataGridController.SelectedIndex);

                    }
                }
            }
        }
        
        private void TurnONController_Click(object sender, RoutedEventArgs e)
        {
            lock (LocalControllerList)
            {
                for (int i = 0; i < LocalControllerList.Count; i++)
                {
                    if (i == dataGridController.SelectedIndex)
                    {
                        LocalControllerList[i].TurnOn();
                    }
                }
            }

        }

        private void TurnOFFController_Click(object sender, RoutedEventArgs e)
        {
            lock (LocalControllerList)
            {
                for (int i = 0; i < LocalControllerList.Count; i++)
                {
                    if (i == dataGridController.SelectedIndex)
                    {
                        LocalControllerList[i].TurnOff();

                    }
                }
            }
        }
    }
}
