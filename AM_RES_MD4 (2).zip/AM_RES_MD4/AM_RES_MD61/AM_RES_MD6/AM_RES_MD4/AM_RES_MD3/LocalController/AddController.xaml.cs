﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for AddController.xaml
    /// </summary>
    public partial class AddController : Window
    {
        public AddController()
        {
            InitializeComponent();
            string path = $"../../../LocalController/bin/Debug/Controllers1/controller.txt";

            if (!File.Exists(path))
            {
                FileStream fileStream = new FileStream(path, FileMode.CreateNew);
                fileStream.Flush();
                fileStream.Close();
            }
            else
            {
                FileStream fileStream = new FileStream(path, FileMode.Append);
                fileStream.Flush();
                fileStream.Close();
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                
                
                LocalController.LocalControllers lc = new LocalControllers(TextBoxCode.GetHashCode().ToString());
                MainWindow.LocalControllerList.Add(lc);
                MainWindow.localControllersIds.Add(lc.LCCode);

                string file = $"../../../LocalController/bin/Debug/Controllers1/controller.txt";

                FileStream fs = new FileStream(file, FileMode.Append, FileAccess.Write);
                if (fs.CanWrite)
                {
                    byte[] buffer = Encoding.Default.GetBytes(lc.LCCode + "\n");
                    fs.Write(buffer, 0, buffer.Length);


                }

                fs.Flush();
                fs.Close();

                this.Close();
            }

        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private bool Validate()
        {
            bool result = true;

            

            if (TextBoxCode.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelCodeGreska.Content = "Obavezan unos!";
                TextBoxCode.BorderBrush = Brushes.Red;
                TextBoxCode.BorderThickness = new Thickness(2);
            }
            else
            {
                try
                {
                    int code = int.Parse(TextBoxCode.Text.Trim());

                    if (code < 0)
                    {
                        result = false;
                        LabelCodeGreska.Content = "Mora biti pozitivan broj!";
                        TextBoxCode.BorderBrush = Brushes.Red;
                        TextBoxCode.BorderThickness = new Thickness(2);

                    }
                    else
                    {
                        foreach (LocalControllers ls in MainWindow.LocalControllerList)
                        {
                            if (ls.LCCode == code.ToString())
                            {
                                result = false;
                                LabelCodeGreska.Content = "Kontroler sa tim kodom već postoji!";
                                TextBoxCode.BorderBrush = Brushes.Red;
                                TextBoxCode.BorderThickness = new Thickness(2);
                            }
                        }

                    }
                }catch(Exception)
                {
                    result = false;
                    LabelCodeGreska.Content = "Nekorektan unos!";
                    TextBoxCode.BorderBrush = Brushes.Red;
                    TextBoxCode.BorderThickness = new Thickness(2);
                }
            }
            return result;

        }
    }
}
