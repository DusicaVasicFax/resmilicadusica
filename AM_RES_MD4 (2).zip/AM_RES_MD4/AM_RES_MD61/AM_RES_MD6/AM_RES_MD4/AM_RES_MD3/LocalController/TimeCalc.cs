﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LocalController
{
    public class TimeCalc
    {
        public static int ThreadTime()
        {
            string path = $@"./Times";
            string[] files = Directory.GetFiles(path);
            int vreme = 0;

            XDocument doc = XDocument.Load("../../../../../AM_RES_MD4/AM_RES_MD3/LocalController/bin/Debug/Times/vreme.xml");

            foreach (string f in files)
            {
                
                lock (f)
                {
                    var controllerFile = XDocument.Load(f);//ucita controllers
                    XElement item = XElement.Load(f);//ucita controller
                    XElement el = item.Element("controller");
                    XAttribute atr = el.Attribute("time");
                    
                    vreme = Int32.Parse(atr.Value);

                }
            }

            return vreme;
        }

        public static int ThreadTimeDevice()
        {
            string path = $@"./DevicesTimes";
            string[] files = Directory.GetFiles(path);
            int vreme = 0;

            XDocument doc = XDocument.Load("../../../../../AM_RES_MD4/AM_RES_MD3/LocalController/bin/Debug/DevicesTimes/device_time.xml");

            foreach (string f in files)
            {

                lock (f)
                {
                    var controllerFile = XDocument.Load(f);//ucita controllers
                    XElement item = XElement.Load(f);//ucita controller
                    XElement el = item.Element("controller");
                    XAttribute atr = el.Attribute("time");

                    vreme = Int32.Parse(atr.Value);

                }
            }

            return vreme;
        }
    }
}
