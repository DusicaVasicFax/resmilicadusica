﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        private LocalDevices device;
        public static List<string> typeList = new List<string>() { "Digital", "Analog" };
        public static List<string> destinationList = new List<string>() { "Local controller", "AMS" };
        public static List<string> pomocna = new List<string>() { "/" };


        public Update(LocalDevices dev)
        {
            InitializeComponent();


            device = dev;
            textBoxCode.Text = device.LDCode.ToString();
            
            
           
            comboBoxType.SelectedValue = device.LDType.ToString();

            if (AddDevice.pom == "AMS")
            {
                AMS.IsChecked = true;
                comboBoxController.SelectedValue = "/";
                comboBoxController.ItemsSource = AddDevice.pomocna;
            }
            else
            {
                LK.IsChecked = true;
                comboBoxController.SelectedValue = device.LocalDeviceControllerCode.ToString();
                comboBoxController.ItemsSource = MainWindow.localControllersIds;

            }


            comboBoxType.ItemsSource = typeList;
            
            
        }

        private bool Validate()
        {
            bool result = true;

            if (textBoxCode.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelCodeGreska.Content = "Obavezan unos!";
                textBoxCode.BorderBrush = Brushes.Red;
                textBoxCode.BorderThickness = new Thickness(2);

            }
            else
            {
                try
                {
                    int kod = int.Parse(textBoxCode.Text.Trim());

                    if (kod < 0)
                    {
                        result = false;
                        LabelCodeGreska.Content = "Mora biti pozitivan broj!";
                        textBoxCode.BorderBrush = Brushes.Red;
                        textBoxCode.BorderThickness = new Thickness(2);
                    }
                    
                }
                catch (Exception)
                {
                    result = false;
                    LabelCodeGreska.Content = "Nekorektan unos!";
                    textBoxCode.BorderBrush = Brushes.Red;
                    textBoxCode.BorderThickness = new Thickness(2);
                }

            }


           
            if (comboBoxType.SelectedItem == null)
            {
                result = false;
                LabelTypeGreska.Content = "Obavezan odabir!";
                comboBoxType.BorderBrush = Brushes.Red;
                comboBoxType.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelTypeGreska.Content = String.Empty;
                comboBoxType.BorderBrush = Brushes.Transparent;
            }

            
            if (AMS.IsChecked == false && LK.IsChecked == false)
            {
                result = false;
                LabelDestGreska.Content = "Obavezan odabir!";
            }
            else
            {
                LabelDestGreska.Content = String.Empty;

            }

            if (comboBoxController.SelectedItem == null)
            {
                result = false;
                labelKontrolerGreska.Content = "Obavezan odabir!";
                comboBoxController.BorderBrush = Brushes.Red;
                comboBoxController.BorderThickness = new Thickness(2);

            }
            else
            {
                labelKontrolerGreska.Content = String.Empty;
                comboBoxController.BorderBrush = Brushes.Transparent;
            }
            
            return result;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                lock (Window1.LocalDeviceList)
                {
                    device.LDCode = textBoxCode.Text.ToString();
                    // device.LDLimit = Int32.Parse(textBoxLimit.Text.ToString());
                    device.LDType = comboBoxType.SelectedValue.ToString();


                    if (AMS.IsChecked == true)
                    {
                        device.LDDestination = AMS.IsChecked.ToString();
                    }
                    else
                    {
                        device.LDDestination = LK.IsChecked.ToString();
                    }
                    
                    device.LocalDeviceControllerCode = comboBoxController.SelectedValue.ToString();

                    Window1.LocalDeviceList.ResetBindings();
                    this.Close();
                }
            }
        }

        private void AMS_LayoutUpdated(object sender, EventArgs e)
        {
            if (AMS.IsChecked == true)
            {
                //comboBoxController.Visibility = Visibility.Collapsed;
                comboBoxController.ItemsSource = pomocna;
            }
            else
            {
                comboBoxController.Visibility = Visibility.Visible;
                comboBoxController.ItemsSource = MainWindow.localControllersIds;
            }
        }
    }
}
