﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xaml;
using System.Xml;
using System.Xml.Linq;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for AddDevice.xaml
    /// </summary>
    public partial class AddDevice : Window
    {
        public static List<string> typeList = new List<string>() { "Digital", "Analog" };
       
        public static List<string> pomocna = new List<string>() {"/"};
        public static string cek = "";
        public static string pom = "";

        //XmlWriter xmlWriter;

        public AddDevice()
        {
            InitializeComponent();
            comboBoxType.ItemsSource = typeList;
            
            
            //comboBoxController.ItemsSource = MainWindow.localControllersIds;

            string path = $"../../../LocalController/bin/Debug/Devices1/device.txt";

            if (!File.Exists(path))
            {
                FileStream fileStream = new FileStream(path, FileMode.CreateNew);
                fileStream.Flush();
                fileStream.Close();
            }
            else
            {
                FileStream fileStream = new FileStream(path, FileMode.Append);
                fileStream.Flush();
                fileStream.Close();
            }
            
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                lock (Window1.LocalDeviceList)
                {

                    textBoxCode.Text = textBoxCode.GetHashCode().ToString();

                    if (AMS.IsChecked == true)
                    {
                        cek = AMS.IsChecked.ToString();
                        pom = "AMS";
                    }
                    else
                    {
                        cek = LK.IsChecked.ToString();
                        pom = "LK";
                    }

                    LocalDevices dev = new LocalDevices(textBoxCode.Text, comboBoxType.SelectedItem.ToString(), pom, comboBoxController.SelectedItem.ToString());
                    Window1.LocalDeviceList.Add(dev);

                    foreach (LocalControllers lc in MainWindow.LocalControllerList)
                    {
                        if (lc.LCCode.Equals(comboBoxController.SelectedItem.ToString()))
                        {
                            lc.Devices.Add(dev);
                        }
                    }

                    string file = $"../../../LocalController/bin/Debug/Devices1/device.txt";

                    FileStream fs = new FileStream(file, FileMode.Append, FileAccess.Write);
                    if (fs.CanWrite)
                    {
                        byte[] buffer = Encoding.Default.GetBytes(dev.LDCode + "\n");
                        fs.Write(buffer, 0, buffer.Length);
                    }


                    fs.Flush();
                    fs.Close();


                    SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Downloads\Microsoft.SkypeApp_kzf8qxf38zg5c!App\All\AM_RES_MD6\AM_RES_MD6\AM_RES_MD4\AM_RES_MD3\Database\Database1.mdf;Integrated Security=True");
                    connection.Open();

                    SqlCommand sqlCommand = new SqlCommand("INSERT INTO DeviceTable (DeviceId,Value,Time,ControllerId) VALUES (@DeviceId,@Value,@Time,@ControllerId));", connection);

                    sqlCommand.Parameters.AddWithValue("@DeviceId",dev.LDCode);
                    sqlCommand.Parameters.AddWithValue("@Value",dev.LDValue);
                    sqlCommand.Parameters.AddWithValue("@Time",dev.LDTimestamp);
                    sqlCommand.Parameters.AddWithValue("@ControllerId",dev.LocalDeviceControllerCode);
                    sqlCommand.ExecuteNonQuery();
                    
                    this.Close();
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private bool Validate()
        {
            bool result = true;

            if (textBoxCode.Text.Trim().Equals(String.Empty))
            {
                result = false;
                LabelCodeGreska.Content = "Obavezan unos!";
                textBoxCode.BorderBrush = Brushes.Red;
                textBoxCode.BorderThickness = new Thickness(2);

            }else
            {
                try
                {
                    int kod = int.Parse(textBoxCode.Text.Trim());

                    if (kod < 0)
                    {
                        result = false;
                        LabelCodeGreska.Content = "Mora biti pozitivan broj!";
                        textBoxCode.BorderBrush = Brushes.Red;
                        textBoxCode.BorderThickness = new Thickness(2);
                    }else
                    {
                        foreach(LocalDevices ld in Window1.LocalDeviceList)
                        {
                            if(ld.LDCode == kod.ToString())
                            {
                                result = false;
                                LabelCodeGreska.Content = "Uređaj sa tim kodom već postoji!";
                                textBoxCode.BorderBrush = Brushes.Red;
                                textBoxCode.BorderThickness = new Thickness(2);
                            }
                        }
                     
                    }
                }
                catch (Exception)
                {
                    result = false;
                    LabelCodeGreska.Content = "Nekorektan unos!";
                    textBoxCode.BorderBrush = Brushes.Red;
                    textBoxCode.BorderThickness = new Thickness(2);
                }

            }

            if (comboBoxType.SelectedItem == null)
            {
                result = false;
                LabelTypeGreska.Content = "Obavezan odabir!";
                comboBoxType.BorderBrush = Brushes.Red;
                comboBoxType.BorderThickness = new Thickness(2);
            }
            else
            {
                LabelTypeGreska.Content = String.Empty;
                comboBoxType.BorderBrush = Brushes.Transparent;
            }
            
            if (AMS.IsChecked == false && LK.IsChecked == false)
            {
                result = false;
                LabelDestGreska.Content = "Obavezan odabir!";
            }
            else
            {
                LabelDestGreska.Content = String.Empty;

            }

            if (comboBoxController.SelectedItem == null)
            {
                result = false;
                labelKontrolerGreska.Content = "Obavezan odabir!";
                comboBoxController.BorderBrush = Brushes.Red;
                comboBoxController.BorderThickness = new Thickness(2);

            }
            else
            {
                labelKontrolerGreska.Content = String.Empty;
                comboBoxController.BorderBrush = Brushes.Transparent;
            }

            return result;
        }

        
        private void AMS_LayoutUpdated(object sender, EventArgs e)
        {
            if (AMS.IsChecked == true)
            {
                //comboBoxController.Visibility = Visibility.Collapsed;
                comboBoxController.ItemsSource = pomocna;
            }
            else
            {
                //comboBoxController.Visibility = Visibility.Visible;
                comboBoxController.ItemsSource = MainWindow.localControllersIds;
            }
        }
    }
}
