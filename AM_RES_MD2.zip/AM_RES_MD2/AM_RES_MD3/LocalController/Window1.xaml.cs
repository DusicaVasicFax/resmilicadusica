﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    /// 

    public partial class Window1 : Window
    {
        public static BindingList<LocalDevices> LocalDeviceList { get; set; }
          

        public Window1()
        {

            InitializeComponent();
            LocalDeviceList = new BindingList<LocalDevices>();
            DataContext = this;


        }

        private void AddNewDevice_Click(object sender, RoutedEventArgs e)
        {
            AddDevice ad = new AddDevice();
            ad.ShowDialog();
        }

        private void DeleteDevice_Click(object sender, RoutedEventArgs e)
        {
           Window1.LocalDeviceList.RemoveAt(dataGridDevice.SelectedIndex);
        }

        private void TurnON_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalDeviceList.Count; i++)
            {
                if (i == dataGridDevice.SelectedIndex)
                {
                    LocalDeviceList[i].TurnOn();
                }
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            Update ad = new Update((LocalDevices)dataGridDevice.SelectedItem);
            ad.ShowDialog();
        }

        private void TurnOFF_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalDeviceList.Count; i++)
            {
                if (i == dataGridDevice.SelectedIndex)
                {
                    LocalDeviceList[i].TurnOff();

                }
            }
        }
    }
}
