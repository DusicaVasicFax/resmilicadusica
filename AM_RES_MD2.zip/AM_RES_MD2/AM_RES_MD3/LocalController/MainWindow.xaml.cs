﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace LocalController
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public static ObservableCollection<LocalController.LocalControllers> LocalControllerList { get; set; }
        public static ObservableCollection<string> localControllersIds { get; set; }
        Random rand = new Random();
        XmlWriter xmlWriter;
        XmlWriter xmlWriter1;
        Window1 win = new Window1();

        public MainWindow()
        {
            InitializeComponent();
            
            LocalControllerList = new ObservableCollection<LocalControllers>();
            localControllersIds = new ObservableCollection<string>();
           
            //win.Owner = this;
            win.Show();
            DataContext = this;
            /*
            ChangeValue();
            SendToAMS();
            DeleteBuffer();*/
        }

        private void AddNewController_Click(object sender, RoutedEventArgs e)
        {
            AddController ac = new AddController();
            ac.ShowDialog();

        }


       

        private void DeleteController_Click(object sender, RoutedEventArgs e)
        {
            LocalController.LocalControllers lc = MainWindow.LocalControllerList.ElementAt(dataGridController.SelectedIndex);
            List<LocalDevices> pom = Window1.LocalDeviceList.ToList();
            foreach (LocalDevices ld in pom)
            {
                if (ld.LocalDeviceControllerCode.Equals(lc.LCCode))
                {
                    //   Window1.LocalDeviceList.Remove(ld);
                    MessageBox.Show("Ažurirajte kontroler kod uređaja sa kodom " + ld.LDCode + " , zbog prestanka rada kontrolera sa kodom " + lc.LCCode);
                }
                
            }
            MainWindow.localControllersIds.RemoveAt(dataGridController.SelectedIndex);
            MainWindow.LocalControllerList.RemoveAt(dataGridController.SelectedIndex);


        }
        
        private void TurnONController_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalControllerList.Count; i++)
            {
                if (i == dataGridController.SelectedIndex)
                {
                    LocalControllerList[i].TurnOn();
                }
            }

        }

        private void TurnOFFController_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < LocalControllerList.Count; i++)
            {
                if (i == dataGridController.SelectedIndex)
                {
                    LocalControllerList[i].TurnOff();

                }
            }
        }
    }
}
